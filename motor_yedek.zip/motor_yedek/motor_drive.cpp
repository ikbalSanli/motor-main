#include "motor_drive.h"
#include <iostream>
#include <fstream>
#include <unistd.h>

#define GPIO_CHIP "/dev/gpiochip0"

void MotorDrive::writeToFile(const std::string& path, const std::string& value) {
    std::ofstream fs(path);
    if (!fs.is_open()) {
        std::cerr << "File open error: " << path << "\n";
        return;
    }
    fs << value;
    fs.close();
}

MotorDrive::MotorDrive(const std::string& pwm_chip_path,
                       const std::string& channel,
                       int direction_pin,
                       int enable_pin,
                       const std::string& name,
                       bool invert_dir)
    : pwm_chip(pwm_chip_path),
      pwm_channel(channel),
      dir_pin(direction_pin),
      en_pin(enable_pin),
      motor_name(name),
      chip(nullptr),
      dir_line(nullptr),
      en_line(nullptr),
      is_active(false),
      invert_direction(invert_dir),
      current_dir(true)
{
    pwm_path = pwm_chip + "/pwm" + pwm_channel;
    connectMotor();
}

MotorDrive::~MotorDrive() {
    stop();
    if (en_line) gpiod_line_release(en_line);
    if (dir_line) gpiod_line_release(dir_line);
    if (chip) gpiod_chip_close(chip);
    writeToFile(pwm_chip + "/unexport", pwm_channel);
}

void MotorDrive::connectMotor() {
    writeToFile(pwm_chip + "/export", pwm_channel);
    usleep(200000);

    chip = gpiod_chip_open(GPIO_CHIP);
    if (!chip) {
        std::cerr << "GPIO chip acilamadi!\n";
        return;
    }

    dir_line = gpiod_chip_get_line(chip, dir_pin);
    if (!dir_line) {
        std::cerr << "DIR line alinmadi: " << dir_pin << "\n";
        return;
    }

    en_line = gpiod_chip_get_line(chip, en_pin);
    if (!en_line) {
        std::cerr << "EN line alinmadi: " << en_pin << "\n";
        return;
    }

    gpiod_line_request_output(dir_line, "motor_dir", 0);
    gpiod_line_request_output(en_line, "motor_en", 0);  
    std::cout << motor_name << " initialized\n";
}

void MotorDrive::setDirection(bool direction) {
    current_dir = invert_direction ? !direction : direction;
    gpiod_line_set_value(dir_line, current_dir ? 1 : 0);
}

void MotorDrive::setEnable(bool enable) {
    gpiod_line_set_value(en_line, enable ? 0 : 1);  
    std::cout << motor_name << " Enable: " << (enable ? "ON" : "OFF") << "\n";
}

void MotorDrive::setSpeed(int speed) {
    if (speed < 0 || speed > 100) return;

    if (speed == 0) {
        stop();
        return;
    }

    int minFreq = 400;
    int maxFreq = 1200;

    int freq = minFreq + (speed * (maxFreq - minFreq)) / 100;
    int period = 1000000000 / freq;
    int duty = period / 2;

    writeToFile(pwm_path + "/period", std::to_string(period));
    writeToFile(pwm_path + "/duty_cycle", std::to_string(duty));

    if (!is_active) {
        writeToFile(pwm_path + "/enable", "1");
        is_active = true;
    }
}


void MotorDrive::drive(char direction, int speed) {
    if (direction != '-' && direction != '+') {
        std::cerr << "Yon '+' veya '-' olmali\n";
        return;
    }

    setDirection(direction == '-');
    setSpeed(speed);

    std::cout << motor_name << " Drive: "
              << direction << speed << "%\n";
}

void MotorDrive::stop() {
    if (is_active) {
        writeToFile(pwm_path + "/enable", "0");
        is_active = false;
    }
}
