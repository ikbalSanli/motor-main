#ifndef MOTOR_DRIVE_H
#define MOTOR_DRIVE_H

#include <string>
#include <gpiod.h>

class MotorDrive {
private:
    std::string pwm_chip;
    std::string pwm_channel;
    std::string pwm_path;
    int dir_pin;
    int en_pin;
    std::string motor_name;
    struct gpiod_chip* chip;
    struct gpiod_line* dir_line;
    struct gpiod_line* en_line;
    bool is_active;
    bool invert_direction;
    bool current_dir;
    
    void writeToFile(const std::string& path, const std::string& value);
    void connectMotor();  
    void setDirection(bool direction);
    void setSpeed(int speed);
    
public:
    MotorDrive(const std::string& pwm_chip_path, const std::string& channel, 
               int direction_pin, int enable_pin, const std::string& name = "Motor", 
               bool invert_dir = false);
    
    ~MotorDrive();
    
    void setEnable(bool enable);
    void drive(char direction, int speed);
    
    void stop();
};

#endif // MOTOR_DRIVE_H
