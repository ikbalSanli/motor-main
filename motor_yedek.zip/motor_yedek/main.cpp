#include <unistd.h>
#include "motor_drive.h"

#define MOTOR1_PWM_CHIP "/sys/class/pwm/pwmchip2"
#define MOTOR1_PWM_CHANNEL "0"
#define MOTOR1_DIR_PIN 136
#define MOTOR1_EN_PIN 85

#define MOTOR2_PWM_CHIP "/sys/class/pwm/pwmchip3"
#define MOTOR2_PWM_CHANNEL "0"
#define MOTOR2_DIR_PIN 137
#define MOTOR2_EN_PIN 96

int main() {
    MotorDrive motor1(MOTOR1_PWM_CHIP, MOTOR1_PWM_CHANNEL, MOTOR1_DIR_PIN, MOTOR1_EN_PIN, "Motor 1");
    MotorDrive motor2(MOTOR2_PWM_CHIP, MOTOR2_PWM_CHANNEL, MOTOR2_DIR_PIN, MOTOR2_EN_PIN, "Motor 2");


    motor1.drive('+', 60);
    motor2.drive('+', 60);
    sleep(3);

    motor1.drive('-', 60);
    motor2.drive('-', 60);
    sleep(3);

    motor1.setEnable(0);
    motor2.setEnable(0);
    sleep(2);

    motor1.setEnable(1);
    motor2.setEnable(1);
    sleep(1);

    motor1.drive('-', 100);
    motor2.drive('+', 100);
    sleep(3);

    motor1.drive('+', 100);
    motor2.drive('-', 100);
    sleep(3);

    motor1.setEnable(0);
    motor2.setEnable(0);
    sleep(2);

    motor1.setEnable(1);
    motor2.setEnable(1);
    sleep(1);

    motor1.drive('+', 60);
    motor2.drive('+', 60);
    sleep(3);

    motor1.drive('-', 30);
    motor2.drive('+', 30);
    sleep(3);


    motor1.stop();
    motor2.stop();

    return 0;
}
