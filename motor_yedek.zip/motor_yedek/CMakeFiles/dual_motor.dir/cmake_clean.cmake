file(REMOVE_RECURSE
  "CMakeFiles/dual_motor.dir/main.cpp.o"
  "CMakeFiles/dual_motor.dir/main.cpp.o.d"
  "CMakeFiles/dual_motor.dir/motor_drive.cpp.o"
  "CMakeFiles/dual_motor.dir/motor_drive.cpp.o.d"
  "dual_motor"
  "dual_motor.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/dual_motor.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
