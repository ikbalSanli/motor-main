
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/orin3/Downloads/motor/main.cpp" "CMakeFiles/dual_motor.dir/main.cpp.o" "gcc" "CMakeFiles/dual_motor.dir/main.cpp.o.d"
  "/home/orin3/Downloads/motor/motor_drive.cpp" "CMakeFiles/dual_motor.dir/motor_drive.cpp.o" "gcc" "CMakeFiles/dual_motor.dir/motor_drive.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
