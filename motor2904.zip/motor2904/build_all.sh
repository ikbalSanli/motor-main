#!/bin/bash

echo "=== [1/2] libmotor_drive.so derleniyor... ==="
cd /home/orin3/Downloads/motor
g++ -shared -fPIC -o libmotor_drive.so motor_drive.cpp -lgpiod

if [ $? -ne 0 ]; then
    echo "HATA: .so derlenemedi!"
    exit 1
fi
echo "OK: libmotor_drive.so guncellendi"

echo ""
echo "=== [2/2] Qt projesi derleniyor... ==="
cd ~/build-untitled1-Desktop-Debug
make -j4 2>&1

if [ $? -ne 0 ]; then
    echo "HATA: Qt projesi derlenemedi!"
    exit 1
fi

echo ""
echo "=== Tum derleme tamamlandi! ==="
